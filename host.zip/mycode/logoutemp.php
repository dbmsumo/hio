<?php
	echo "<script>alert('loging out');window.top.location='employee.html';</script>"
?>