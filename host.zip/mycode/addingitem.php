<?php
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
	 $count=0;
		$itemname= $_POST['itemname'];
		$itemsize= $_POST['itemsize'];
		$datepur= $_POST['datep'];
		$broughtfrom= $_POST['broughtfrom'];
		
		$batchno= $_POST['batchno'];
                $quantitys= $_POST['quantity'];
		$manfd= $_POST['manfdate'];
		$expdate= $_POST['expdate'];
                $innum= $_POST['innum'];
		$billno= $_POST['billno'];
		$cost=$_POST['cost'];
		$c=0;
                $n=0;
                $sql1="select * from itemlist";
		$result1=$connect->query($sql1);
		while($row=$result1->fetch_assoc()){
			
			if($row['itemname']==$itemname and $row['itemsize']==$itemsize and $row['manufacturer']==$broughtfrom){
				$n=1;
				$c=$row['quantity'];
			
			}
		}
		
		$p=$c+$quantitys;
		if($n==0){
			$s="insert into itemlist values('$itemname','$itemsize','$broughtfrom','$p')";
			$r=$connect->query($s);
			if(!$r){
				echo "cannot enter insert" ;
		
			}
			
		}
		else{
			$s1="update itemlist set quantity='$p' where itemname='$itemname' and itemsize='$itemsize' and manufacturer='$broughtfrom'";
			$r1=$connect->query($s1);
			if(!$r1){
				echo "cannot enter" ;
		
			}
			
			
		}
                $n=0;
                $c=0;
		$sql1="select * from item";
		$result1=$connect->query($sql1);
		while($row=$result1->fetch_assoc()){
			
			if($row['itemname']==$itemname and $row['itemsize']==$itemsize and $row['broughtfrom']==$broughtfrom and $row['batchno']==$batchno){
				$n=1;
				$c=$row['quantity'];
			
			}
		}
		
		$p=$c+$quantitys;
		if($n==0){
			$s="insert into item values('$itemname','$itemsize','$broughtfrom','$batchno','$quantitys','$cost')";
			$r=$connect->query($s);
			if(!$r){
				echo "cannot enter insert" ;
		
			}
			
		}
		else{
			$s1="update item set quantity='$p' where itemname='$itemname' and itemsize='$itemsize' and broughtfrom='$broughtfrom' and batchno='$batchno'";
			$r1=$connect->query($s1);
			if(!$r1){
				echo "cannot enter" ;
		
			}
			
			
		}


		$s="insert into stockregister values('$itemname','$itemsize','$datepur','$c','$broughtfrom','$quantitys','$batchno','$manfd','$expdate','$innum','$billno','-','$p')";
		$result=$connect->query($s);
		if(!$result){
			echo "cannot enter" ;
		
		}
		else{
			echo "<script>alert('stock added');window.location='button.html';</script>";
		}
		   
		
		
		
	}
?>
  