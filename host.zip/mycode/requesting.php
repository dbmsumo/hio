<?php
	 mysql_connect('localhost','root','') or die(mysql_error());
	 mysql_select_db("login") or die(mysql_error());
			$i=$_GET['id'];
			$a="yes";
			$fin=mysql_query("update item set extrastockneeded='$a' where itemid='$i'")or die(mysql_error());
			if($fin)
			{
				echo"<script>alert('record updated');window.location='usermain.html';</script>";
			}
			
?>