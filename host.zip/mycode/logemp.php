<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
		$username= $_POST['username'];
		$password= $_POST['password'];
		$_SESSION['iid']=$username;
		$sql="select *from employee where empid='$username' and password='$password'";
		$_SESSION['id']=$_POST['username'];
		$result=$connect->query($sql);
		if($result->num_rows>0){
			while($row=$result->fetch_assoc()){
				echo"<script>alert( 'hello'.row['name'])</script>";
				header("Location: empframe.html");	
			}	
		}
		else
			header("Location: employee1.html");
	}
?>
  