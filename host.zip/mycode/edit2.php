 <?php
	 mysql_connect('localhost','root','') or die(mysql_error());
	 mysql_select_db("login") or die(mysql_error());
		$eid = $_GET['id'];
	
		$res = mysql_query("select * from item where itemid =('$eid')")or die(mysql_error());
		$row=mysql_fetch_row($res);
		if($_POST)
		{
			$q=$_POST["quantity"];
			$c=$_POST["cost"];
			$d=$_POST["discount"];
			$i=$_POST["id"];
			$fin=mysql_query("update item set quantity='$q',cost='$c',discount='$d',extrastockneeded='no' where itemid='$i'")or die(mysql_error());
			if($fin)
			{
				echo"<script>alert('record updated');window.location='frame3.html';</script>";
			}
		}	
?>
<html>
<style>
body{
	background-image:url("ed.jpg");
	min-height: 645px;
	background-position: center;
	background-repeat:no-repeat;
	background-attachment:fixed;
	position:relative;
	color:black;
	}
</style>
	<body align=center>
		<h2> the data of <?php echo $row[1];?> is.....</h2>
		<form method="post">
			<input type="hidden" value="<?php echo $row[0]; ?>" name="id">
			Quantity:<input type="text" value="<?php echo $row[2]; ?>" name="quantity"><br><br>
			Cost:<input type="text" value="<?php echo $row[3]; ?>" name="cost"><br><br>
			Discount:<input type="text" value="<?php echo $row[5]; ?>" name="discount"><br>
			<input type="submit" value="submit">
		</form>
	</body>
			
</html>








		 