<?php
	session_start();
	$_SESSION['myValue']=3;
?>