<html>
<head>
<style>
body{
	background-image:url("d.jpg");
	background-repeat:no-repeat;
	background-attachment:fixed;
	background-size:1400px 1000px;
}
img {
  opacity: 0.5;
}
</style>
</head>
<body  align="center">
<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}
	else
	{
		$id=$_POST['itemid'];
		$sql="select *from orders where itemid='$id'";
		$res3=$connect->query($sql);
		echo "<h1>"."details of $id..."."</h1>";
		echo "<table border='1' align='center'>
	<tr>
	<th>Id</th>
	<th>name</th>
	<th>quantity</th>
	<th>ordered date</th>
	
	</tr>";
		if($res3->num_rows>0){
	while($row=$res3->fetch_assoc())
	 {
		echo "<tr>";
		echo "<td>" . $row['customerid'] . "</td>";
		echo "<td>" . $row['itemname'] . "</td>";
		echo "<td>" . $row['quantity'] . "</td>";
		echo "<td>" . $row['date'] . "</td>";
		echo "</tr>";
		
	}
echo "</table>";
		}
	}
	?>
	</body>
	</html>