<?php
	echo '<script>alert("Order placed THANKYOU FOR SHOPPING");window.location="itemdis.php";</script>';
?>