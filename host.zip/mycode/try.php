<?php
$date = date('Y-m-d');
echo $date;
?>