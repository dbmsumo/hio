<?php
	$connect=new mysqli('database-2.cahdqplrqa3m.us-east-2.rds.amazonaws.com','admin','adminsumo','database-2');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
		$username= $_POST['username'];
		$password= $_POST['password'];
		$sql="select *from admin where username='$username' and password='$password'";
		$result=$connect->query($sql);
		if($result->num_rows>0){
			while($row=$result->fetch_assoc()){
				header("Location:adminfram.html");
			}	
		}
		else
			header("Location: admin1.html");
	}
?>
  
