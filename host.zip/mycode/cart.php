<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{ 
		$eid = $_SESSION['itemid'];
		$sql1="select * from item where itemid =('$eid')"or die(mysql_error());
		$res=$connect->query($sql1);
		$row=$res->fetch_assoc();
		$id=$_SESSION['id'];
		$qua=$_POST["quantity"];
		$count=0;
		$sql1="select *from cart where customerid='$id'";
		$result1=$connect->query($sql1);
		while($row1=$result1->fetch_assoc()){
			if($row1['itemid']==$row['itemid']){
				$qua=$row1['quantity']+$qua;
				$count=1;
			}
		}
		$sql3="select *from item";
		$res3=$connect->query($sql3);
		if($res3->num_rows>0)
	while($row=$res3->fetch_assoc())
	 {
		if($row['itemid']==$eid){
			if($row['quantity']>=$qua){
			if($count==0){
		$sql2="insert into cart values('$id','$eid','$row[itemname]','$row[cost]','$row[discount]','$qua')"or die(mysql_error());
		$res1=$connect->query($sql2);
		if($res1){
		echo "<script>alert('item added to cart');window.location='itemdis.php'</script>";
		}
		}
		else{
			echo "hi";
			echo $row['itemid'];
			echo $id;
			$sql2="update cart set quantity='$qua' where customerid='$id' and itemid='$row[itemid]'"or die(mysql_error());
			$res1=$connect->query($sql2);
			if($res1){
			echo "<script>alert('quantity updated');window.location='itemdis.php'</script>";
			}
		}
	}
	else
	{
		echo "<script>alert('sorry! only $row[quantity] are in stock');window.location='itemdis.php'</script>";
	}
		}
	}
	}
?>
