<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
		$id=$_SESSION['id'];
		$sql="select * from customer where username=('$id')"or die(mysql_error());
		$res=$connect->query($sql);
	}
	
	if($res->num_rows>0){
	while($row=$res->fetch_assoc()){
		echo '<h2 align="center">';
	echo "cardno:".$row['cardno'];
	echo '<br></br><a href="card.php"><button>PAY WITH THIS CARD</button><br></br></a>';
	echo '</h2>';
	}
	}
		
?>
<html>
<style>
body{
	background-image:url("car.jpg");
	min-height: 745px;
	background-position: center;
	background-repeat:no-repeat;
	background-attachment:fixed;
	position:relative;
	color:black;
	}
</style>
	
</html>
