<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}
	else
	{
		$id1=$_GET['id1'];
		$sql="delete from customer where username='$id1'";
		$res3=$connect->query($sql);
		if($res3)
			{
				echo"<script>alert('sucessfully removed');window.location='frame3.html';</script>";
			}
		
	}
	?>