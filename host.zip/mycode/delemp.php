<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}
	else
	{
		$id=$_GET['id'];
		$sql="delete from employee where empid='$id'";
		$res3=$connect->query($sql);
		if($res3)
			{
				echo"<script>alert('sucessfully removed');window.location='frame3.html';</script>";
			}
		
	}
	?>