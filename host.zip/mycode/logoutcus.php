<?php
	echo "<script>alert('loging out');window.top.location='customer.html';</script>"
?>