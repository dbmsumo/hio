<html>
<html>
<head>
<style>
body{
	background-image:url("ca.jpg");
	background-repeat:no-repeat;
	background-attachment:fixed;
	background-size:1200px 600px;
	opacity=0.05;
	z-index:-2;
	#color:red;
	
}
</style>
<body>
<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{ 
		$id=$_SESSION['id'];
		$c=0;
		$sql1="select * from cart where customerid =('$id')"or die(mysql_error());
		$res=$connect->query($sql1);
	}
	if($res->num_rows>0){
			$sum1=0;
			$sum2=0;
	echo "<h1>"."CART..."."</h1>";
		echo "<table border='1'>
	<tr>
	<th>Id</th>
	<th>name</th>
	<th>quantity</th>
	<th>cost</th>
	<th>actual cost</th>
	<th>discount</th>
	<th>present cost</th>
	<th>option</th>
	<th>edit</th>
	</tr>";
		
	while($row=$res->fetch_assoc())
	 {
		 $a=$row['quantity']*$row['cost'];
		 $b=$row['quantity']*$row['cost']*((100-$row['discount'])*0.01);
		echo "<tr>";
		echo "<td>" . $row['itemid'] . "</td>";
		echo "<td>" . $row['itemname'] . "</td>";
		echo "<td>" . $row['quantity'] . "</td>";
		echo "<td>" . $row['cost'] . "</td>";
		echo "<td>".$a."</td>";
		if($sum1>0){
		$c=1;}
		echo "<td>" . $row['discount'] . "</td>";
		echo "<td>" .$b. "</td>";
		echo "<td>"."<a href='delcart.php?id=$row[itemid]'><button>remove from cart</button></a><br>"."</td>";
		echo "<td>"."<a href='details.php?id=$row[itemid]'><button>edit</button></a><br>"."</td>";
		echo "</tr>";
		$sum1=$sum1+$a;
		$sum2=$sum2+$b;
	}
	
	$_SESSION['cost']=$sum2;
echo "</table>";
echo "<h1>"."total:".$sum2."</h1>";
echo "<h2>"."Your Savings:".($sum1-$sum2)."</h2>";
echo "<a href='pay.php'><button>Place Order</button></a>";

		}
		else{
			
			echo '<script>alert("Oopps!You havent added anything to cart!!");window.location="itemdis.php";</script>';;
		}
?>
</body>
</html>