<html>
<style>
body{
	background-image:url("ed.jpg");
	min-height: 645px;
	background-position: center;
	background-repeat:no-repeat;
	background-attachment:fixed;
	position:relative;
	color:black;
	}
</style>
<h2>Here is the list of items in the data base</h2>
<h3>note:here yes indicates that the employee requested for extra stock</h3>
<h3>
<body align=center>
<?php
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
		$sql="select *from item";
		$res=$connect->query($sql);
	}
	
	if($res->num_rows>0){
	while($row=$res->fetch_assoc())
		echo "$row[itemid] extrastockneeded:$row[extrastockneeded]<a href='edit2.php?id=$row[itemid]'> edit </a><a href ='delitem.php?id=$row[itemid]'> 	delete</a><br>";
	}
?>	
</body>
</h3>
</html>

	