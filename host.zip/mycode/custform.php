<?php
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
		$count=0;
		$Name= $_POST['Name'];
		$Cardno= $_POST['card'];
		$mobilnum= $_POST['number'];
		$address= $_POST['add'];
		$Mailid= $_POST['id'];
		$username= $_POST['username'];
		$password= $_POST['password'];
		$sql1="select *from customer";
		$result1=$connect->query($sql1);
		while($row=$result1->fetch_assoc()){
			if($row['emailid']==$Mailid){
				$count=1;
			echo "<script>alert('email id already exists');window.location='regis_customer.html';</script>";
			}
		}
		if($count==0){
		$sql="insert into customer values('$Name','$Cardno','$mobilnum','$address','$Mailid','$username','$password')";
		$result=$connect->query($sql);
		if(!$result){
			echo "cannot enter" ;
		
		}
		else
			echo "<script>alert('registration successfull');window.location='customer.html';</script>";
		}
		}
?>
  