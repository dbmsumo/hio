<?php
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
		$name= $_POST['name'];
		$card= $_POST['card'];
		$number= $_POST['number'];
		$comment= $_POST['add'];
		$emailid= $_POST['id'];
		$uname= $_POST['username'];
		$password= $_POST['psw'];
		$rpass= $_POST['rpsw'];
		if($password==$rpass){
		$sql="insert into employee values('$name','card','$number','$comment','$emailid','$uname','$password')";
		}
		$result=$connect->query($sql);
		if(!$result){
			echo "cannot enter" ;
		
		}
		else{
			header('Refresh:1; url=buttons.html');
			echo 'sucessfully added an employee';
		}
	}
?>
  