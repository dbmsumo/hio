<html>
<head>
<style>
body{
	background-image:url("d.jpg");
	background-repeat:no-repeat;
	background-attachment:fixed;
	background-size:1400px 1000px;
}
img {
  opacity: 0.5;
}
</style>
</head>
<body  align="center">
<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}
	else
	{
		$name=$_POST['name'];
		$size=$_POST['size'];
		
		$sql="select *from stockregister where itemname='$name' and itemsize='$size'";
		$res3=$connect->query($sql);
		echo "<h1>"." STOCK REGISTER "."</h1><br>";
		echo "<h1>"."ITEMNAME:$name"."</h1>";
		echo "<h1>"."ITEMSIZE:$size "."</h1>";
		
		echo "<table border='1' align='center'>
	<tr>
	<th>Date purchased</th>
	<th>opening balance</th>
	<th>Brought from</th>
	<th>Quantity brought</th>
	<th>Batch no</th>
	<th>Manufacturing date</th>
	<th>Expiry date</th>
	<th>Invoice number</th>
	<th>Bill no</th>
	<th>sales</th>
	<th>Closing balance</th>
	
	</tr>";
		if($res3->num_rows>0){
	while($row=$res3->fetch_assoc())
	 {
		echo "<tr>";
		echo "<td>" . $row['date purchased'] . "</td>";
		echo "<td>" . $row['openingbal'] . "</td>";
		echo "<td>" . $row['brought from'] . "</td>";
		echo "<td>" . $row['quantity brought'] . "</td>";
		echo "<td>" . $row['batchno'] . "</td>";
		echo "<td>" . $row['manufacturing date'] . "</td>";
		echo "<td>" . $row['expiry date'] . "</td>";
		echo "<td>" . $row['invoice num'] . "</td>";
		echo "<td>" . $row['bill no'] . "</td>";
		echo "<td>" . $row['sales'] . "</td>";
		echo "<td>" . $row['closing bal'] . "</td>";
		echo "</tr>";
		
	}
echo "</table>";
		}
	}
	?>
	</body>
	</html>