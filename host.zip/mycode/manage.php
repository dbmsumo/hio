<?php
	session_start();
	 mysql_connect('localhost','root','') or die(mysql_error());
	 mysql_select_db("login") or die(mysql_error());
		$iid = $_SESSION['iid'];
	
		$res = mysql_query("select * from employee where empid =('$iid')")or die(mysql_error());
		$row=mysql_fetch_row($res);
		if($_POST)
		{
			$q=$_POST["address"];
			$c=$_POST["mobilenumber"];
			$d=$_POST["mailid"];
			$i=$_POST["id"];
			$fin=mysql_query("update employee set address='$q',mobilenum='$c',emailid='$d' where empid='$i'")or die(mysql_error());
			if($fin)
			{
				echo"<script>alert('record updated');window.location='frame3.html';</script>";
			}
		}	
?>
<html>
<style>
body{
	background-image:url("ed.jpg");
	min-height: 645px;
	background-position: center;
	background-repeat:no-repeat;
	background-attachment:fixed;
	position:relative;
	color:black;
	}
</style>
	<body align=center>
		<h2> the data of <?php echo $row[1];?> is.....</h2>
		<form method="post">
			<input type="hidden" value="<?php echo $row[0]; ?>" name="id">
			address:<input type="text" value="<?php echo $row[3]; ?>" name="address"><br><br>
			mobilenumber:<input type="text" value="<?php echo $row[2]; ?>" name="mobilenumber"><br><br>
			mailid:<input type="text" value="<?php echo $row[5]; ?>" name="mailid"><br>
			<input type="submit" value="submit">
		</form>
	</body>
			
</html>
