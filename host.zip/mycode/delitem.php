<?php
	 mysql_connect('localhost','root','') or die(mysql_error());
	 mysql_select_db("login") or die(mysql_error());
		$eid = $_GET['id'];
		$fin=mysql_query("delete from item where itemid='$eid'")or die(mysql_error());
			if($fin)
			{
				echo"<script>alert('record updated');window.location='frame3.html';</script>";
				#echo"<script>alert('record updated');window.location='frame3.html';</script>";
			}
?>			