<html>
<html>
<head>
<style>
body{
	background-image:url("or.jpg");
	background-repeat:no-repeat;
	background-attachment:fixed;
	background-size:1400px 600px;
	#color:white;
	opacity=0.05;
	z-index:-2;
	#color:red;
	
}
</style>
<body>
<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{ 
	$id=$_SESSION['id'];
	$sql3="select * from orders where customerid =('$id') order by date"or die(mysql_error());
		$res3=$connect->query($sql3);
		echo "<h1>"."YOURS ORDERS..."."</h1>";
		echo "<table border='1'>
		<tr>
	<th>Id</th>
	<th>name</th>
	<th>cost</th>
	<th>quantity</th>
	<th>ordered date</th>
	<th>expected delivery date</th>
	<th>status</th>
	<th>option</th>
	</tr>";
		if($res3->num_rows>0){
	while($row3=$res3->fetch_assoc()){
		echo "<tr>";
		echo "<td>" . $row3['itemid'] . "</td>";
		echo "<td>" . $row3['itemname'] . "</td>";
		echo "<td>" . $row3['cost'] . "</td>";
		echo "<td>" . $row3['quantity'] . "</td>";
		$date = strtotime("+1 day", strtotime($row3['date']));
		echo "<td>" .$row3['date']. "</td>";
		echo "<td>".date("Y-m-d", $date)."</td>";
		$d=$row3['date'];
		$now = time();
		$your_date = strtotime($d);
$datediff = $now - $your_date;
	$day=round($datediff / (60 * 60 *12));
if($day <= "1")
{
		echo "<td>"."processing"."</td>";
		echo "<td>"."<a href='deleteorder.php?id1=$row3[itemid]&qua=$row3[quantity]'><button>cancel order</button></a><br>"."</td>";
}
		else
		{
			echo "<td>"."delivered"."</td>";
		echo "<td>"."<a href='deleteorder.php?id1=$row3[itemid]&qua=$row3[quantity]'><button>Return order</button></a><br>"."</td>";
		}
		echo "</tr>"; 
	}
		}
		else{
			
			echo '<script>alert("Oopps! You havent ordered anythings yet!!");window.location="itemdis.php";</script>';;
		}
		echo "</table>";
	}
	
?>
</body>
</html>