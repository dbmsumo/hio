<?php
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
		$file=$_FILES['itemimage']['tmp_name'];
		$im=addslashes(file_get_contents($_FILES['itemimage']['tmp_name' ]));
		$sql="insert into image values('$im')";
		$result=$connect->query($sql);
		if(!$result){
			echo "cannot enter" ;
		
		}
		else{
		echo"image entered";
		}
		
	}
?>