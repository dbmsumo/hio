

<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}
	else
	{
		$sql="select *from employee";
		$res3=$connect->query($sql);
		echo "<h2 align='center'>"."details of employees..."."</h2>";
		echo "<table border='1' align='center'>
	<tr>
	<th>empId</th>
	<th>name</th>
	<th>salary</th>
	<th>option</th>
	</tr>";
	if($res3->num_rows>0){
	while($row=$res3->fetch_assoc())
	 {
		echo "<tr>";
		echo "<td>" . $row['empid'] . "</td>";
		echo "<td>" . $row['name'] . "</td>";
		echo "<td>" . $row['salary'] . "</td>";
		echo "<td>" . "<a href='delemp.php?id=$row[empid]'><button>delete emp</button></a><br/><br/>" . "</td>";
		echo "</tr>";
		
	}
	}
echo "</table>";
	}
	?>
	
	