<?php
session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
			$id=$_SESSION['id'];
			$eid=$_GET['id1'];
			$qua=$_GET['qua'];
			echo $eid;
			echo $qua;
		$sql3="select *from item where itemid='$eid'";
		$res3=$connect->query($sql3);
		$row=$res3->fetch_assoc();
		echo $row['quantity'];
			$q=$row['quantity']+$qua;
			echo $q;
			$sql4="update item set quantity=$q where itemid='$eid'"or die(mysql_error());
			$res2=$connect->query($sql4);
			if($res2)
				$sql5="delete from orders where customerid='$id' and itemid='$eid' and quantity='$qua'"or die(mysql_error());
				$res5=$connect->query($sql5);
				if($res5)
				{
					echo "<script>alert('your money will be refunded soon');window.location='orders.php'</script>";
				
				
				}
				
		
	}
?>