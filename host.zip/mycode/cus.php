<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}
	else
	{
		$sql="select *from customer";
		$res3=$connect->query($sql);
		echo "<h2 align='center'>"."details of customer..."."</h2>";
		echo "<table border='1' align='center'>
	<tr>
	<th>mailId</th>
	<th>name</th>
	<th>phonenum</th>
	<th>option</th>
	</tr>";
	if($res3->num_rows>0){
	while($row=$res3->fetch_assoc())
	 {
		echo "<tr>";
		echo "<td>" . $row['emailid'] . "</td>";
		echo "<td>" . $row['name'] . "</td>";
		echo "<td>" . $row['mobilenum'] . "</td>";
		echo "<td>" . "<a href='delcus.php?id1=$row[username]'><button>delete customer</button></a><br/><br/>" . "</td>";
		echo "</tr>";
		
	}
	}
echo "</table>";
	}
	?>