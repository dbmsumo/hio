<html>
<style>
.foto{
  width: 350px;
  height: 450px;
  padding: 10px;
	}
.col{
  float: left;
  width: 28.33%;
  padding: 15px;
}
}
.row::after {
  content: "";
  clear: both;
  display: table;
}
.smtng{
	float:left;
	margin-left: 20px ;
	padding:10px;
}
	</style>
<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
		$sql="select *from item";
		$res=$connect->query($sql);
	}
	
	echo "<div class='row'>";
	if($res->num_rows>0){
	while($row=$res->fetch_assoc())
			{

	$_SESSION['itemid']=$row['itemid'];
				echo "<div class='col'>";
				echo '<div id="smtng">';
					echo "<h2 align='center'>".$row['itemname']."</h2>";
				echo"<a href='details.php?id=$row[itemid]'><img  class='foto' src='data:image/jpeg;base64,".base64_encode( $row['image'] )."'/></a>";
			
				echo "<h3 align='left'>"."cost:".$row['cost']."  "."discount:".$row['discount']."%"."</h3>";
				echo '</div>';
				echo"</div>";
			}
		}
		
	echo"</div>";
?>
</html>