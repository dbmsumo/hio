<html>
<style>
.foto{
  width: 350px;
  height: 250px;
  padding: 10px;
	}
	</style>
<?php
	session_start();
	 mysql_connect('localhost','root','') or die(mysql_error());
	 mysql_select_db("login") or die(mysql_error());
		$eid = $_GET['id'];
		$res = mysql_query("select * from item where itemid =('$eid')")or die(mysql_error());
		$row=mysql_fetch_row($res);
		$_SESSION['itemid']=$eid;
		echo '<div align="center">';
		echo "<h2>";
		echo '<img  class="foto" src="data:image/jpeg;base64,'.base64_encode( $row[7] ).'"/>';
		echo '<br></br>';
		echo 'cost:'.$row[3];
		echo '<br></br>';
		echo 'description:'.$row[4];
		echo '<br></br>';
		echo ' discount:'.$row[5];
		echo '<h2>';
		echo '<html><form action="cart.php" method="POST"><label for="quantity"><b>Quantity</b></label>
    <input type="text"  name="quantity" value="1" required><br/></html>';
		echo "<a href='itemdis.php'> go back </a>";
		echo '<input type="submit" value="Add to cart">';
		echo '</div>';
?>
</html>