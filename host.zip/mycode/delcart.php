<?php
	session_start();
	 mysql_connect('localhost','root','') or die(mysql_error());
	 mysql_select_db("login") or die(mysql_error());
	 $id=$_SESSION['id'];
		$eid = $_GET['id'];
		$fin=mysql_query("delete from cart where itemid='$eid' and customerid='$id'")or die(mysql_error());
			if($fin)
			{
				echo"<script>alert('item deleted');window.location='viewcart.php';</script>";
				#echo"<script>alert('record updated');window.location='frame3.html';</script>";
			}
?>			