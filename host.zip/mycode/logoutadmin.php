<?php
	echo "<script>alert('loging out');window.top.location='admin.html';</script>"
?>