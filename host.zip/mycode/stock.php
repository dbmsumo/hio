<html>
<html>
<head>
<style>
body{
	background-image:url("hand.jpg");
	background-repeat:no-repeat;
	background-attachment:fixed;
	background-size:1000px 700px;
	opacity=0.05;
	z-index:-2;
	#color:red;
	
}
</style>
<body>
<h2>Here is the list of items in the data base</h2>
<h3>note:you can request for the extra stock by clicking the button</h3>
<h4>
<?php
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
		$sql="select *from item";
		$res=$connect->query($sql);
	}
	echo '<div class="bg-image"></div>';
	echo "<table border='1'>
	<tr>
	<th>Id</th>
	<th>name</th>
	<th>quantity</th>
	<th>option</th>
	</tr>";
	if($res->num_rows>0){
	while($row=$res->fetch_assoc())
	 {
		echo "<tr>";
		echo "<td>" . $row['itemid'] . "</td>";
		echo "<td>" . $row['itemname'] . "</td>";
		echo "<td>" . $row['quantity'] . "</td>";
	 echo "<td>"."<a href='requesting.php?id=$row[itemid]'><button>request extra stock</button></a><br>"."</td>";
		echo "</tr>"; 
	}
echo "</table>";
	}
?>	
</h4>
</body>
</html>
	