<html>
<body>


<form action="button.html" method="post"  >

<input type="submit" value="ok">
</form>
</body>
</html>

<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{ 
		
		$sql1="select * from itemlist "or die(mysql_error());
		$res=$connect->query($sql1);
	}
	if($res->num_rows>0){
			
	echo "<h1>"."Total Stock"."</h1>";
		echo "<table border='1'>
	<tr>
	<th>Name</th>
	<th>Size</th>
	<th>Manufacturer</th>
	<th>Quantity</th>
	
	
	</tr>	";
	while($row=$res->fetch_assoc())
	 {
		
		echo "<tr>";
		echo "<td>" . $row['itemname'] . "</td>";
		echo "<td>" . $row['itemsize'] . "</td>";
		echo "<td>" . $row['manufacturer'] . "</td>";
		echo "<td>" . $row['quantity'] . "</td>";
		
		
		echo "</tr>";
		
	}
	echo "</table>";
}
		$sql1="select * from item "or die(mysql_error());
		$res=$connect->query($sql1);
	
	if($res->num_rows>0){
			
	echo "<h1>"."Total Stock with batch no"."</h1>";
		echo "<table border='1'>
	<tr>
	<th>Name</th>
	<th>Size</th>
	<th>Manufacturer</th>
	<th>Batch no</th>
	
	<th>stock Quantity</th>
	
	
	</tr>	";
	while($row=$res->fetch_assoc())
	 {
		
		echo "<tr>";
		echo "<td>" . $row['itemname'] . "</td>";
		echo "<td>" . $row['itemsize'] . "</td>";
		echo "<td>" . $row['broughtfrom'] . "</td>";
		echo "<td>" . $row['batchno'] . "</td>";
		echo "<td>" . $row['quantity'] . "</td>";
		
		
		echo "</tr>";
		
	}
}
	
	
	
?>




