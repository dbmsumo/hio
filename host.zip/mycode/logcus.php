<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{ 
		$username= $_POST['username'];
		$password= $_POST['password'];
		$_SESSION['id']=$username;
		$sql="select *from customer where username='$username' and password='$password'";
		$result=$connect->query($sql);
		if($result->num_rows>0){
			while($row=$result->fetch_assoc()){
				echo "<script>alert('welcome to supermarket');window.top.location='cusframe.html';</script>";
			}
		}
		else
			echo  "<script>alert('enter valid username and password');window.top.location='customer1.html';</script>";
	}
?>
  