
<?php
	session_start();
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{ 
		$id=$_SESSION['id'];
		$cost=$_SESSION['cost'];
		$date = date('Y-m-d H:i:s');
		$sql1="select * from cart where customerid =('$id')"or die(mysql_error());
		$res=$connect->query($sql1);
	}
	if($res->num_rows>0){
		#echo "hi";
	while($row=$res->fetch_assoc()){
		$qua=$row['quantity'];
		$eid=$row['itemid'];
		echo $eid;
		$sql3="select *from item";
		$res3=$connect->query($sql3);
		if($res3->num_rows>0)
	while($row1=$res3->fetch_assoc())
	 {
		if($row1['itemid']==$eid){
			$q=$row1['quantity']-$qua;
			echo $row1['itemid'];
			echo $q;
			if($q>=5){
			$sql4="update item set quantity=$q where itemid='$eid'"or die(mysql_error());}
			else{
				$sql4="update item set quantity=$q,extrastockneeded='yes' where itemid='$eid'"or die(mysql_error());}
			$res2=$connect->query($sql4);
		}
	 }
		$sql="insert into orders values ('$row[customerid]','$row[itemid]','$row[itemname]','$row[cost]','$row[quantity]','$date')"or die(mysql_error());
		$res2=$connect->query($sql);
	}
	}
	$sql3="delete from cart where customerid='$id'"or die(mysql_error());
		$res3=$connect->query($sql3);
		if($res3){
		echo '<script>alert("Order placed THANKYOU FOR SHOPPING");window.location="itemdis.php";</script>';}
?>