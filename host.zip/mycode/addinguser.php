<?php
	$connect=new mysqli('localhost','root','','login');
	if($connect->connect_error){
		echo("connection failed");
	}else
	{
		$count=0;
		$userid= $_POST['empid'];
		$name= $_POST['name'];
		$tel= $_POST['mobilenum'];
		$comment= $_POST['address'];
		$sal= $_POST['salary'];
		$emailid= $_POST['emailid'];
		$password= $_POST['password'];
		$sql1="select *from employee";
		$result1=$connect->query($sql1);
		while($row=$result1->fetch_assoc()){
			if($row['empid']==$userid){
				$count=1;
			echo "<script>alert('emp id already exists');window.location='adduser.html';</script>";
			}
		}
		if($count==0){
		$sql="insert into employee values('$userid','$name','$tel','$comment','$sal','$emailid','$password')";
		$result=$connect->query($sql);
		if(!$result){
			echo "cannot enter" ;
		
		}
		else{
			header('Refresh:1; url=frame3.html');
			echo 'sucessfully added an employee';
		}
	}
	}
?>
  